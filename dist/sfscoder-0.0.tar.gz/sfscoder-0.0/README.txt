sfs_coder is a front end to the forward simulation
software SFS_CODE.  See http://uricchio.github.io/sfs_coder
for details.

